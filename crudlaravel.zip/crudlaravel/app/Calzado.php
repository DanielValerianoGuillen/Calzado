<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Calzado extends Model
{
    protected $fillable = ['tipo','color','talla','marca','genero','edades'];
}
