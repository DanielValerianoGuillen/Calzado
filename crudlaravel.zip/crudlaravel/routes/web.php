<?php

use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::resource('libro', 'LibroController');
Route::get('api/v1/libros','LibroController@getLibros');
Route::get('/home', 'HomeController@index')->name('home');


Route::resource('calzado', 'CalzadoController');
Route::get('api/v1/calzados','CalzadoController@getCalzados');
Route::get('/home', 'HomeController@index')->name('home');

Route::resource('venta', 'VentaController');
Route::get('api/v1/ventas','VentaController@getVentas');
Route::get('/home', 'HomeController@index')->name('home');